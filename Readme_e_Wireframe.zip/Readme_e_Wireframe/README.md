# Campanha do Agasalho Mackenzie

**Matheus Goto — RA: 10736324**
**Felipe de Sousa — RA: 10737002**
**Vinicius Bizarria - RA: 10739202**

---

## Sobre o projeto

Site desenvolvido para apoiar a **Campanha do Agasalho** realizada dentro do Instituto Presbiteriano Mackenzie, com o objetivo de centralizar as informações da campanha, facilitar a doação de agasalhos, cobertores e calçados, e ajudar a comunidade acadêmica a localizar o ponto de coleta mais próximo de sua região.

---

## Processo de Ideação

O ponto de partida foi identificar um problema real e recorrente dentro da própria universidade: campanhas de arrecadação de inverno costumam depender de cartazes físicos e comunicação informal (grupos de WhatsApp, murais), o que dificulta que a comunidade acadêmica saiba onde, quando e o que doar.

A partir disso, definimos o escopo do site em torno de três necessidades da campanha:

1. **Divulgação clara** — o que pode ser doado (agasalhos, cobertores, calçados) e por que a campanha existe.
2. **Localização do ponto de coleta** — o Mackenzie possui mais de uma unidade (ex: Higienópolis, Alphaville), então um mesmo doador pode não saber qual campus fica mais próximo de sua casa. Isso motivou a inclusão de um filtro por bairro/região entre os pontos de coleta.
3. **Canal de contato** — um formulário simples para quem quer doar ou se voluntariar na organização da campanha.

[SUPOSIÇÃO] Os pontos de coleta e datas usados no protótipo são provisórios, até confirmação junto ao órgão responsável pela campanha dentro do Mackenzie (DA, Pastoral Universitária ou equivalente).

---

## Caráter Extensionista

O projeto se conecta a uma demanda real da comunidade Mackenzie: a arrecadação de agasalhos beneficia pessoas em situação de vulnerabilidade fora da universidade, e depende diretamente da mobilização de estudantes, professores e funcionários como doadores. O site não é um exercício isolado — ele existe para ser efetivamente usado durante o período da campanha, como ferramenta de divulgação e apoio à coleta.

[SUPOSIÇÃO] A validação plena do caráter extensionista depende do contato direto com a organização responsável pela campanha e da confirmação de que o site será, de fato, utilizado como canal oficial ou de apoio — esse é um passo posterior a este check-in.

---

**Telas planejadas:**

| Tela | Conteúdo |
|---|---|
| Home | Chamada da campanha + categorias de doação aceitas |
| Pontos de Coleta | Lista de campi participantes com filtro por bairro/região |
| Formulário | Doação ou voluntariado, com validação em JavaScript |
| Sobre a Campanha | Explicação do propósito e de quem recebe as doações |
| Vídeo | Vídeo de divulgação da campanha |

---

## Tecnologias

- **HTML5** — estrutura das páginas
- **CSS3** — estilização e responsividade (Flexbox + media queries)
- **JavaScript** — validação do formulário e filtro de pontos de coleta por bairro

---

## Repositório

**Link do GitHub: https://github.com/fscardoso7/Projeto-Web-Mobile** 
---

## Explicação do código

---

## Conclusão

